let API_KEY = "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";
chrome.storage.sync.get(["openai_key"], r => { if (r.openai_key) API_KEY = r.openai_key; });

chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
  if (req.type === "SOLVE") {
    if (!API_KEY) { sendResponse({ success: false, error: "API kalit yo‘q" }); return; }

    fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer " + API_KEY
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [{ role: "user", content: req.prompt }],
        temperature: 0,
        max_tokens: 500
      })
    })
    .then(r => r.json())
    .then(d => {
      const text = d.choices?.[0]?.message?.content || "";
      sendResponse({ success: true, answer: text });
    })
    .catch(() => sendResponse({ success: false, error: "Internet xatosi" }));
    return true;
  }
});