let answers = [];
let currentIndex = 0;
let autoPlay = null;
let inactivityTimer = null;
let isWindowActive = false;
let isProcessing = false;
let holdTimer = null;

// Mini oyna yaratish
function createMiniWindow() {
  if (document.getElementById('ai-helper-window')) return;

  const miniWindow = document.createElement('div');
  miniWindow.id = 'ai-helper-window';
  miniWindow.style.cssText = `
    position: fixed;
    bottom: 35px;
    right: 20px;
    width: 280px;
    background: transparent;
    border: none;
    border-radius: 0;
    padding: 12px;
    color: white;
    font-family: Arial, sans-serif;
    font-size: 12px;
    font-weight: normal;
    text-align: center;
    z-index: 999999;
    box-shadow: none;
    display: none;
    backdrop-filter: none;
    user-select: none;
  `;

  const content = document.createElement('div');
  content.id = 'ai-answer-text';
  content.textContent = 'AI faol';
  content.style.color = 'rgba(204, 204, 204, 0.8)';

  miniWindow.appendChild(content);
  document.body.appendChild(miniWindow);
}

// Javoblarni parse qilish
function parseAIAnswers(text) {
  const regex = /(\d+)[\s\.\-\)\:]+\s*([A-D])/gi;
  const matches = [...text.matchAll(regex)];
  if (matches.length === 0) return [];

  return matches.map(m => ({
    num: m[1],
    ans: m[2],
    full: `${m[1]}-${m[2]}`
  }));
}

// Javobni ko‘rsatish
function showAnswer(index) {
  if (answers.length === 0) return;
  const i = ((index % answers.length) + answers.length) % answers.length;
  currentIndex = i;

  const content = document.getElementById('ai-answer-text');
  content.innerHTML = answers[i].full;
  content.style.color = 'rgba(204, 204, 204, 0.9)';
}

// Avto-play
function startAutoPlay() {
  stopAutoPlay();
  autoPlay = setInterval(() => {
    showAnswer(currentIndex + 1);
    resetInactivityTimer();
  }, 6000);
}

function stopAutoPlay() {
  if (autoPlay) clearInterval(autoPlay);
  autoPlay = null;
}

// ⭐ 1.5 soniyada HAR DOIM avtomatik yopish
function resetInactivityTimer() {
  clearTimeout(inactivityTimer);
  inactivityTimer = setTimeout(() => {
    toggleWindow(true);
  }, 7000);
}

// Oynani ochish/yopish
function toggleWindow(forceHide = null) {
  createMiniWindow();
  if (forceHide !== null) {
    isWindowActive = !forceHide;
  } else {
    isWindowActive = !isWindowActive;
  }
  const miniWindow = document.getElementById('ai-helper-window');
  miniWindow.style.display = isWindowActive ? 'block' : 'none';

  if (isWindowActive) {
    if (answers.length > 0) {
      showAnswer(currentIndex);
      startAutoPlay();
    } else {
      document.getElementById('ai-answer-text').textContent = 'AI faol';
    }
    resetInactivityTimer();
  } else {
    stopAutoPlay();
    clearTimeout(inactivityTimer);
  }
}

// Savollarni yig‘ish
function collectQuestions() {
  const questions = [];
  document.querySelectorAll('.table-test').forEach((table, i) => {
    const q = table.querySelector('.test-question p')?.textContent.trim();
    if (!q) return;
    const opts = [];
    table.querySelectorAll('.answers-test li').forEach(li => {
      const v = li.querySelector('.test-variant')?.textContent.trim().replace(/[^A-D]/gi, '');
      const t = li.querySelector('label p, label')?.textContent.trim();
      if (v && t) opts.push(`${v}. ${t}`);
    });
    if (opts.length >= 2) questions.push({ num: i + 1, q, opts });
  });
  return questions;
}

function buildPrompt(qs) {
  let p = "Qanday bo'lmasin 100% to'g'ri javobni tanla. Format: 1-A 2-C\n\n";
  qs.forEach(x => {
    p += `${x.num}. ${x.q}\n`;
    x.opts.forEach(o => p += o + "\n");
    p += "\n";
  });
  p += "Javoblar:";
  return p;
}

// AI dan javob olish
async function solveAll() {
  if (isProcessing) return;
  isProcessing = true;

  const content = document.getElementById('ai-answer-text');
  if (content) content.textContent = 'Yuklanmoqda...';

  const qs = collectQuestions();
  if (qs.length === 0) {
    answers = [];
    if (content) content.textContent = 'Savol topilmadi';
    isProcessing = false;
    return;
  }

  const prompt = buildPrompt(qs);

  try {
    const res = await chrome.runtime.sendMessage({ type: "SOLVE", prompt });
    if (res.success) {
      const text = res.answer.trim();
      answers = parseAIAnswers(text);
      if (answers.length === 0) {
        if (content) content.textContent = 'Javob yo‘q';
      } else if (isWindowActive) {
        currentIndex = 0;
        showAnswer(0);
        startAutoPlay();
        resetInactivityTimer();
      }
    } else {
      if (content) content.textContent = 'Xato: ' + res.error;
    }
  } catch {
    if (content) content.textContent = 'Internet yo‘q';
  }

  isProcessing = false;
}

// Sichqoncha va klaviatura boshqaruvi
document.addEventListener('wheel', e => {
  if (!isWindowActive) return;
  e.preventDefault();
  showAnswer(currentIndex + (e.deltaY > 0 ? 1 : -1));
  stopAutoPlay();
  startAutoPlay();
  resetInactivityTimer();
}, { passive: false });

document.addEventListener('keydown', e => {
  if (e.key.toLowerCase() === 'z') {
    e.preventDefault();
    toggleWindow();
    return;
  }
  if (e.key.toLowerCase() === 'x') {
    e.preventDefault();
    solveAll();
    return;
  }
  if (!isWindowActive) return;
  if (e.key === 'ArrowUp') {
    e.preventDefault();
    showAnswer(currentIndex - 1);
    stopAutoPlay();
    startAutoPlay();
    resetInactivityTimer();
  } else if (e.key === 'ArrowDown') {
    e.preventDefault();
    showAnswer(currentIndex + 1);
    stopAutoPlay();
    startAutoPlay();
    resetInactivityTimer();
  }
});

// O‘ng tugma – ochish/yopish
document.addEventListener('contextmenu', e => {
  e.preventDefault();
  toggleWindow();
});

// Chap tugma 3 soniya bosib turish – solveAll
document.addEventListener('mousedown', e => {
  if (e.button === 0) {
    holdTimer = setTimeout(() => {
      solveAll();
    }, 1000);
  }
});

document.addEventListener('mouseup', e => {
  if (e.button === 0 && holdTimer) {
    clearTimeout(holdTimer);
    holdTimer = null;
  }
});

document.addEventListener('mouseleave', () => {
  if (holdTimer) {
    clearTimeout(holdTimer);
    holdTimer = null;
  }
});

// Dastlabki ishga tushirish
createMiniWindow();
